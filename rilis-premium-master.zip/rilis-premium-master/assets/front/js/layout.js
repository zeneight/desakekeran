$(document).ready(function(){
  $_wrapperHeight = parseInt($('body').height());
  $('#content').css({'height':$_wrapperHeight-20});
});