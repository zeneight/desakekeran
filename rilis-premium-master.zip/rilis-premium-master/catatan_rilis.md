Di rilis ini, versi 23.02-premium-rev02 [isi disini]. Rilis ini juga berisi penambahan fitur dan perbaikan lain yang diminta Komunitas SID.

Terima kasih pada [isi disini] yang terus berkontribusi.

#### Perbaikan BUG

1. [#6391](https://github.com/OpenSID/OpenSID/issues/6391) Perbaikan menampilkan dan menyembunyikan password pada saat ganti profil.
2. [#6405](https://github.com/OpenSID/OpenSID/issues/6405) Perbaikan validasi token versi dan tanggal berakhir sama.
3. [#6344](https://github.com/OpenSID/OpenSID/issues/6344) Perbaikan validasi karakter pada surat masuk.
4. [#6407](https://github.com/OpenSID/OpenSID/issues/6407) Perbaikan tampilan berantakan pada saat inputan error menggunakan elemen input-grup.
5. [#6417](https://github.com/OpenSID/OpenSID/issues/6417) Perbaikan modul stunting tidak dapat menginput tinggi badan jika menggunakan tanda koma.

#### Perubahan Teknis

1. [#1889](https://github.com/OpenSID/premium/issues/1889) Penyesuaian created_at dan updated_at pada modul DTKS.
2. [#6383](https://github.com/OpenSID/OpenSID/issues/6383) Mengatasi HTML Injection pada form pencarian tema natra.
3. [#1976](https://github.com/OpenSID/premium/issues/1976) Sesuaikan modul jabatan agar bisa digunakan di OpenKAB.
4. [#6403](https://github.com/OpenSID/OpenSID/issues/6403) Penyesuaian penandatangan dokumen kerja sama dengan pengurus baru.
